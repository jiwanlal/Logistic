
export class custompattern{
public onlyalph=/^$|.*\S+.*/
//public onlyalph='[a-z A-Z]+'

}
// Onlyalphabets:any=/^[a-zA-Z\s*\S+.*]+$/