import { Component } from '@angular/core';

@Component({
  selector: 'app-manifest',
  templateUrl: './manifest.component.html',
  styleUrls: ['./manifest.component.sass']
})
export class ManifestComponent {

}
