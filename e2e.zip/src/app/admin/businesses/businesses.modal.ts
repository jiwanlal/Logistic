export class businessmodal {
    success:boolean
    data:Array<businessattribute>
   
  }
  export class businessattribute {
    public  id: number;
    public  business_name: string;
      public Actions 
      public actionIcons
      public popupForm
     
  }
  export class offficemodal {
    success:boolean
    data:Array<officeattribute>
   
  }
  export class officeattribute {
    public officename:string;
    
    
    public  company_id: number;
    public  company_name: string;
    public  country_id: number;
    public  country_name: string;
    public  state_id: number;
    public  state_name: string;
    public post_code_id:number;
    public post_code:string;
    public  city_id: number;
    public  city_name: string;
    public  user_id: number;
    public  user_name: string;
    public  role_id: number;
    public  role_name: string;

      public Actions 
      public actionIcons
      public popupForm
     
  }