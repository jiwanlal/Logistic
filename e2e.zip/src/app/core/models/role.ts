export enum Role {
  Admin = 'Admin',
  Customer = 'Customer',
  Employee = 'Employee',
}
