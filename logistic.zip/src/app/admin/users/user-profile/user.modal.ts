export class ProfileDeatils {
    public address
    public city_id
    public company_id
    public created_at
    public created_by
    public dob
    public email
    public first_name
    public gender
    public id
    public is_visible
    public last_name
    public mobile
    public office_id
    public password
    public post_code_id
    public profile_picture
    public role_id
    public state_id
    public status
    public system_ip
    public system_name
    public updated_at
    public updated_by
   
}
