import { Component } from '@angular/core';

@Component({
  selector: 'app-postalcode',
  templateUrl: './postalcode.component.html',
  styleUrls: ['./postalcode.component.sass']
})
export class PostalcodeComponent {

}
