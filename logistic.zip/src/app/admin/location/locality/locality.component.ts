import { Component } from '@angular/core';

@Component({
  selector: 'app-locality',
  templateUrl: './locality.component.html',
  styleUrls: ['./locality.component.sass']
})
export class LocalityComponent {

}
