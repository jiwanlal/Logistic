
export class custompattern{
public onlyalph='[a-zA-Z_ ]+'
//public onlyalph='[a-z A-Z]+'

}
// Onlyalphabets:any=/^[a-zA-Z\s*\S+.*]+$/