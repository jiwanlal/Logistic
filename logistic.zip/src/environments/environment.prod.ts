export const environment = {
  production: true,
  apiUrl: 'http://34.70.100.59:8080/', 
 //apiUrl:'http://location:4200'
};
